import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

type Props = { src: string; alt: string; className?: string | undefined; label?: string | undefined; eager?: boolean | undefined };

/** Imagem com placeholder elegante enquanto o arquivo real não existir. */
export function SmartImage({ src, alt, className, label, eager }: Props) {
  const ref = useRef<HTMLImageElement>(null);
  const [ok, setOk] = useState(false);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const img = ref.current;
    if (img?.complete) img.naturalWidth > 0 ? setOk(true) : setFailed(true);
  }, []);
  return (
    <div className={cn("relative overflow-hidden bg-placeholder", className)}>
      {!ok && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 p-4 text-center">
          <span className="font-display text-3xl text-gold/80">✦</span>
          <span className="font-display text-lg italic text-primary-foreground/80">{label ?? alt}</span>
          <span className="text-[10px] uppercase tracking-[0.3em] text-primary-foreground/50">Reino Alegre</span>
        </div>
      )}
      {!failed && (
        <img
          ref={ref}
          src={src}
          alt={alt}
          loading={eager ? "eager" : "lazy"}
          decoding="async"
          onLoad={() => setOk(true)}
          onError={() => setFailed(true)}
          className={cn("absolute inset-0 h-full w-full object-cover transition-all duration-700", ok ? "opacity-100" : "opacity-0")}
        />
      )}
    </div>
  );
}
