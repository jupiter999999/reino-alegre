import { useEffect, useState } from "react";
import { X, Send } from "lucide-react";
import { EVENT_TYPES, GUESTS, INTERESTS, PERIODS, buildMessage, waLink, type FormData } from "@/lib/whatsapp";

export type Preset = { eventType?: string; interest?: string };

const empty: FormData = { name: "", eventType: "", eventDate: "", noDate: false, guests: "", interest: "", meetingDate: "", meetingPeriod: "", details: "" };

function Chips({ name, options, value, onChange, error }: { name: string; options: readonly string[]; value: string; onChange: (v: string) => void; error?: boolean | undefined }) {
  return (
    <div role="radiogroup" aria-label={name} className="flex flex-wrap gap-2">
      {options.map((o) => (
        <button type="button" role="radio" aria-checked={value === o} key={o} onClick={() => onChange(o)}
          className={`min-h-11 rounded-full border px-4 py-2 text-sm transition-all ${value === o ? "border-primary bg-primary text-primary-foreground shadow-soft" : `bg-card text-foreground hover:border-gold ${error ? "border-destructive" : "border-border"}`}`}>
          {o}
        </button>
      ))}
    </div>
  );
}

export function ContactModal({ open, preset, onClose }: { open: boolean; preset: Preset; onClose: () => void }) {
  const [f, setF] = useState<FormData>(empty);
  const [errors, setErrors] = useState<Partial<Record<"name"|"eventType"|"guests"|"interest"|"eventDate"|"details", boolean>>>({});
  useEffect(() => {
    if (open) { setF((p) => ({ ...p, ...preset })); setErrors({}); }
    document.body.style.overflow = open ? "hidden" : "";
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, preset, onClose]);
  if (!open) return null;
  const set = <K extends keyof FormData>(k: K, v: FormData[K]) => setF((p) => ({ ...p, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const err = {
      name: f.name.trim().length < 2 || f.name.length > 100,
      eventType: !f.eventType, guests: !f.guests, interest: !f.interest,
      eventDate: !f.noDate && !f.eventDate,
      details: f.details.length > 1000,
    };
    setErrors(err);
    if (Object.values(err).some(Boolean)) return;
    window.open(waLink(buildMessage(f)), "_blank", "noopener,noreferrer");
  };
  const today = new Date().toISOString().slice(0, 10);
  const label = "mb-2 block text-sm font-semibold text-primary";
  const input = "min-h-12 w-full rounded-xl border border-border bg-card px-4 text-base outline-none transition focus:border-gold focus:ring-2 focus:ring-gold/30";

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-primary/60 backdrop-blur-sm animate-in fade-in sm:items-center sm:p-4" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-labelledby="form-title" onClick={(e) => e.stopPropagation()}
        className="max-h-[94vh] w-full max-w-2xl overflow-y-auto rounded-t-3xl bg-background shadow-elegant animate-in slide-in-from-bottom-8 sm:rounded-3xl">
        <div className="sticky top-0 z-10 flex items-start justify-between border-b border-border bg-background/95 px-6 py-5 backdrop-blur">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-gold-deep">Atendimento</p>
            <h2 id="form-title" className="font-display text-3xl text-primary">Conte sobre sua celebração</h2>
          </div>
          <button onClick={onClose} aria-label="Fechar formulário" className="rounded-full p-2 hover:bg-muted"><X /></button>
        </div>
        <form onSubmit={submit} noValidate className="space-y-6 px-6 py-6">
          <div>
            <label htmlFor="nome" className={label}>Nome *</label>
            <input id="nome" maxLength={100} value={f.name} onChange={(e) => set("name", e.target.value)} className={`${input} ${errors.name ? "border-destructive" : ""}`} placeholder="Seu nome" autoComplete="name" />
            {errors.name && <p className="mt-1 text-sm text-destructive">Informe seu nome.</p>}
          </div>
          <div>
            <span className={label}>Qual evento deseja realizar? *</span>
            <Chips name="Tipo de evento" options={EVENT_TYPES} value={f.eventType} onChange={(v) => set("eventType", v)} error={errors.eventType} />
            {errors.eventType && <p className="mt-1 text-sm text-destructive">Selecione o tipo de evento.</p>}
          </div>
          <div>
            <label htmlFor="data" className={label}>Data prevista do evento</label>
            <input id="data" type="date" min={today} disabled={f.noDate} value={f.eventDate} onChange={(e) => set("eventDate", e.target.value)} className={`${input} disabled:opacity-50 ${errors.eventDate ? "border-destructive" : ""}`} />
            <label className="mt-3 flex min-h-11 cursor-pointer items-center gap-3 text-sm">
              <input type="checkbox" checked={f.noDate} onChange={(e) => set("noDate", e.target.checked)} className="h-5 w-5 accent-primary" />
              Ainda não tenho data definida
            </label>
            {errors.eventDate && <p className="text-sm text-destructive">Escolha uma data ou marque "ainda não tenho data".</p>}
          </div>
          <div>
            <span className={label}>Quantidade aproximada de convidados *</span>
            <Chips name="Convidados" options={GUESTS} value={f.guests} onChange={(v) => set("guests", v)} error={errors.guests} />
          </div>
          <div>
            <span className={label}>O que você deseja fazer? *</span>
            <Chips name="Interesse" options={INTERESTS} value={f.interest} onChange={(v) => set("interest", v)} error={errors.interest} />
          </div>
          {f.interest === "Agendar uma reunião" && (
            <div className="rounded-2xl border border-gold/40 bg-gold/10 p-5 animate-in fade-in">
              <span className={label}>Preferência para a reunião</span>
              <input type="date" min={today} aria-label="Data preferida para a reunião" value={f.meetingDate} onChange={(e) => set("meetingDate", e.target.value)} className={`${input} mb-3`} />
              <Chips name="Período" options={PERIODS} value={f.meetingPeriod} onChange={(v) => set("meetingPeriod", v)} />
              <p className="mt-3 text-xs text-muted-foreground">Esta é apenas uma preferência. O horário será confirmado pela nossa equipe.</p>
            </div>
          )}
          <div>
            <label htmlFor="det" className={label}>Conte mais sobre seu evento</label>
            <textarea id="det" rows={4} maxLength={1000} value={f.details} onChange={(e) => set("details", e.target.value)} className={`${input} py-3`} placeholder="Tema da festa, preferências, outras informações..." />
          </div>
          {Object.values(errors).some(Boolean) && <p className="text-sm text-destructive">Preencha os campos obrigatórios destacados.</p>}
          <button type="submit" className="btn-gold w-full justify-center"><Send className="h-5 w-5" /> Enviar pelo WhatsApp</button>
          <p className="text-center text-xs text-muted-foreground">O WhatsApp abrirá com a mensagem pronta. Basta tocar em enviar — o agendamento será confirmado pela equipe.</p>
        </form>
      </div>
    </div>
  );
}
