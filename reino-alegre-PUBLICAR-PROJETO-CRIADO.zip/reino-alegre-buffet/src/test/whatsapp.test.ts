import { describe, it, expect } from "vitest";
import { buildMessage, waLink } from "@/lib/whatsapp";

const base = { name: "Maria Silva", eventType: "Festa infantil", eventDate: "2026-12-20", noDate: false, guests: "De 51 a 100 pessoas", interest: "Agendar uma reunião", meetingDate: "2026-11-25", meetingPeriod: "Tarde", details: "" };

describe("whatsapp message", () => {
  it("includes meeting preference only for meetings", () => {
    expect(buildMessage(base)).toContain("Preferência para reunião: 25/11/2026, à tarde");
    expect(buildMessage({ ...base, interest: "Solicitar um orçamento" })).not.toContain("Preferência");
  });
  it("uses A definir when no date", () => {
    expect(buildMessage({ ...base, noDate: true })).toContain("Data prevista: A definir");
  });
  it("targets the official number", () => {
    expect(waLink("oi")).toBe("https://wa.me/5585996220363?text=oi");
  });
});
