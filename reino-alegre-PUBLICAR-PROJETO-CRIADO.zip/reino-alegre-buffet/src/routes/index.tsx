import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Menu, X, MapPin, Instagram, MessageCircle, PartyPopper, Cake, Users, Briefcase, Sparkles, ArrowRight, CalendarHeart } from "lucide-react";
import { SmartImage } from "@/components/SmartImage";
import { ContactModal, type Preset } from "@/components/ContactModal";
import { siteImages as img, site } from "@/data/siteImages";
import { waLink } from "@/lib/whatsapp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Reino Alegre Buffet — Festas em Fortaleza | Festejar faz bem." },
      { name: "description", content: "Buffet para festas infantis, aniversários, confraternizações e eventos na Maraponga, Fortaleza/CE. Agende sua reunião pelo WhatsApp." },
      { property: "og:title", content: "Reino Alegre Buffet — Festejar faz bem." },
      { property: "og:description", content: "Seu momento especial merece um reino de alegria. Conheça nosso espaço em Fortaleza." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const NAV = [["Início", "inicio"], ["Sobre", "sobre"], ["Eventos", "eventos"], ["Espaço", "espaco"], ["Galeria", "galeria"], ["Contato", "contato"]] as const;
const EVENTS = [
  { t: "Festa infantil", d: "Um dia mágico para os pequenos, com alegria do início ao fim.", i: PartyPopper },
  { t: "Aniversário adulto", d: "Celebre mais um ano reunindo quem você ama.", i: Cake },
  { t: "Confraternização", d: "Encontros especiais para família, amigos e equipes.", i: Users },
  { t: "Evento corporativo", d: "Um ambiente acolhedor para reunir sua empresa.", i: Briefcase },
  { t: "Outra celebração", d: "Tem outra ideia? Conte para a gente.", i: Sparkles },
];
const GALLERY = [
  { src: img.galeriaFesta, alt: "Festa no Reino Alegre", c: "md:col-span-2 md:row-span-2" },
  { src: img.galeriaAniversario, alt: "Aniversário" },
  { src: img.galeriaEspaco, alt: "Nosso espaço" },
  { src: img.galeriaBuffet, alt: "Buffet servido" },
  { src: img.decoracaoJunina, alt: "Decoração junina" },
  { src: img.mesaAzul, alt: "Mesa decorada em azul", c: "md:col-span-2" },
  { src: img.decoracaoPersonalizada, alt: "Decoração personalizada" },
];

const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

function Reveal({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`reveal ${className}`}>{children}</div>;
}

function Index() {
  const [open, setOpen] = useState(false);
  const [preset, setPreset] = useState<Preset>({});
  const [menu, setMenu] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [zoom, setZoom] = useState<number | null>(null);
  const openForm = useCallback((p: Preset = {}) => { setPreset(p); setOpen(true); setMenu(false); }, []);
  const close = useCallback(() => setOpen(false), []);
  const meeting = () => openForm({ interest: "Agendar uma reunião" });

  useEffect(() => {
    const s = () => setScrolled(window.scrollY > 30);
    s(); window.addEventListener("scroll", s, { passive: true });
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && e.target.classList.add("is-visible")), { threshold: 0.12 });
    document.querySelectorAll(".reveal").forEach((el) => io.observe(el));
    return () => { window.removeEventListener("scroll", s); io.disconnect(); };
  }, []);
  useEffect(() => {
    if (zoom === null) return;
    const k = (e: KeyboardEvent) => {
      if (e.key === "Escape") setZoom(null);
      if (e.key === "ArrowRight") setZoom((z) => ((z ?? 0) + 1) % GALLERY.length);
      if (e.key === "ArrowLeft") setZoom((z) => ((z ?? 0) - 1 + GALLERY.length) % GALLERY.length);
    };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [zoom]);

  return (
    <div className="overflow-x-hidden">
      {/* HEADER */}
      <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled || menu ? "bg-primary/95 py-3 shadow-elegant backdrop-blur-md" : "bg-gradient-to-b from-primary/70 to-transparent py-6"}`}>
        <div className="container-x flex items-center justify-between gap-4">
          <button onClick={() => go("inicio")} className="group flex items-center gap-3" aria-label="Reino Alegre — início">
            <span className="grid h-12 w-12 place-items-center rounded-full border border-gold/70 bg-primary/40 font-display text-xl text-gold backdrop-blur transition group-hover:border-gold group-hover:shadow-gold">RA</span>
            <span className="text-left leading-tight text-primary-foreground">
              <span className="block font-display text-2xl tracking-wide">Reino Alegre</span>
              <span className="block text-[10px] font-semibold uppercase tracking-[0.45em] text-gold">Buffet</span>
            </span>
          </button>
          <nav className="hidden items-center gap-8 lg:flex" aria-label="Principal">
            {NAV.map(([l, id]) => <button key={id} onClick={() => go(id)} className="nav-link">{l}</button>)}
          </nav>
          <button onClick={meeting} className="btn-gold hidden !min-h-11 !px-6 lg:inline-flex">Agende sua reunião</button>
          <button onClick={() => setMenu(!menu)} className="rounded-full p-2 text-primary-foreground lg:hidden" aria-label={menu ? "Fechar menu" : "Abrir menu"} aria-expanded={menu}>
            {menu ? <X /> : <Menu />}
          </button>
        </div>
        {menu && (
          <nav className="container-x flex flex-col gap-1 pb-6 pt-4 lg:hidden animate-in fade-in slide-in-from-top-2" aria-label="Mobile">
            {NAV.map(([l, id]) => <button key={id} onClick={() => { setMenu(false); go(id); }} className="min-h-12 border-b border-primary-foreground/10 text-left font-display text-2xl text-primary-foreground">{l}</button>)}
            <button onClick={meeting} className="btn-gold mt-4 justify-center">Agende sua reunião</button>
          </nav>
        )}
      </header>

      {/* HERO — editorial premium */}
      <section id="inicio" className="relative flex min-h-[100svh] items-center overflow-hidden pt-28 pb-24">
        <SmartImage src={img.heroFesta} alt="Festa no Reino Alegre Buffet" eager className="!absolute inset-0" label="Foto principal da festa" />
        <div className="absolute inset-0 bg-hero-overlay" />
        <div className="container-x relative">
          <div className="max-w-3xl text-primary-foreground">
            <p className="eyebrow-light animate-in fade-in slide-in-from-bottom-4 duration-700">
              <span className="ornament-line" />{site.slogan}<span className="ornament-line" />
            </p>
            <h1 className="font-display text-[clamp(3rem,8vw,6.5rem)] font-semibold leading-[0.98] tracking-tight animate-in fade-in slide-in-from-bottom-6 duration-1000">
              Seu momento especial merece um <em className="bg-gradient-to-r from-gold via-[oklch(0.85_0.1_84)] to-gold bg-clip-text italic text-transparent">reino de alegria.</em>
            </h1>
            <p className="mt-7 max-w-xl text-lg leading-relaxed text-primary-foreground/85 animate-in fade-in duration-1000">
              Transformamos celebrações em momentos inesquecíveis. Conheça nosso espaço e conte como podemos fazer parte da sua próxima festa.
            </p>
            <div className="mt-11 flex flex-col gap-4 sm:flex-row animate-in fade-in slide-in-from-bottom-4 duration-1000">
              <button onClick={meeting} className="btn-gold">Agende sua reunião <ArrowRight className="h-4 w-4" /></button>
              <button onClick={() => go("espaco")} className="btn-ghost">Conheça nosso espaço</button>
            </div>
          </div>
        </div>
        {/* faixa inferior decorativa */}
        <div className="absolute inset-x-0 bottom-0 border-t border-primary-foreground/10 bg-primary/40 backdrop-blur-sm">
          <div className="container-x flex flex-wrap items-center justify-center gap-x-10 gap-y-3 py-5 text-[11px] font-semibold uppercase tracking-[0.3em] text-primary-foreground/70">
            <span className="inline-flex items-center gap-2"><span className="text-gold">✦</span> Festas infantis</span>
            <span className="inline-flex items-center gap-2"><span className="text-gold">✦</span> Aniversários</span>
            <span className="inline-flex items-center gap-2"><span className="text-gold">✦</span> Confraternizações</span>
            <span className="hidden items-center gap-2 sm:inline-flex"><span className="text-gold">✦</span> Eventos corporativos</span>
          </div>
        </div>
      </section>

      {/* SOBRE */}
      <section id="sobre" className="section relative">
        <div className="container-x grid items-center gap-16 lg:grid-cols-2">
          <Reveal className="relative pb-20 pr-8 sm:pr-14">
            <SmartImage src={img.heroAmbiente} alt="Ambiente do Reino Alegre" className="frame-gold aspect-[4/5] rounded-[2.5rem] shadow-elegant" />
            <SmartImage src={img.decoracaoPersonalizada} alt="Decoração personalizada" className="!absolute bottom-0 right-0 aspect-square w-1/2 rounded-[2rem] border-[10px] border-background shadow-elegant animate-float-slow" />
            <span className="absolute -left-2 top-8 font-display text-7xl italic text-gold/50 select-none" aria-hidden="true">✦</span>
          </Reveal>
          <Reveal>
            <p className="eyebrow"><span className="ornament-line" />Sobre o buffet</p>
            <h2 className="h2">Um espaço acolhedor para celebrar o que importa.</h2>
            <p className="lead">No Reino Alegre, cada celebração é recebida com carinho. Nosso espaço foi pensado para que você e seus convidados se sintam em casa — num ambiente bonito, alegre e preparado para criar memórias.</p>
            <p className="lead">Da decoração aos detalhes da recepção, acreditamos que celebrar momentos especiais aproxima pessoas. Afinal, <em className="font-display text-xl italic text-gold-deep">festejar faz bem.</em></p>
            <div className="mt-10 grid grid-cols-3 gap-6 border-t border-border pt-9">
              {["Ambiente", "Decoração", "Experiência"].map((t) => (
                <div key={t} className="group">
                  <span className="font-display text-3xl text-gold-deep transition group-hover:text-gold">✦</span>
                  <p className="mt-2 text-sm font-bold uppercase tracking-wider text-primary">{t}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* EVENTOS */}
      <section id="eventos" className="section bg-navy-deep text-primary-foreground">
        <div className="container-x">
          <Reveal className="mx-auto max-w-2xl text-center">
            <p className="eyebrow-light justify-center"><span className="ornament-line" />Eventos<span className="ornament-line" /></p>
            <h2 className="h2 !text-primary-foreground">Que celebração você quer realizar?</h2>
            <p className="lead !text-primary-foreground/75">Escolha uma opção e converse com nossa equipe sobre as possibilidades para o seu evento.</p>
          </Reveal>
          <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
            {EVENTS.map(({ t, d, i: Icon }) => (
              <Reveal key={t} className="group relative flex flex-col overflow-hidden rounded-[1.75rem] border border-primary-foreground/10 bg-primary-foreground/[0.06] p-7 backdrop-blur-sm transition-all duration-500 hover:-translate-y-2.5 hover:border-gold/60 hover:bg-primary-foreground/10 hover:shadow-gold">
                <span className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full bg-gold/10 blur-2xl transition group-hover:bg-gold/25" aria-hidden="true" />
                <span className="grid h-14 w-14 place-items-center rounded-2xl border border-gold/30 bg-gold/15 text-gold transition-all duration-500 group-hover:bg-gold group-hover:text-primary group-hover:shadow-gold"><Icon /></span>
                <h3 className="mt-7 font-display text-[1.65rem] leading-tight">{t}</h3>
                <p className="mt-2.5 flex-1 text-sm leading-relaxed text-primary-foreground/70">{d}</p>
                <button onClick={() => openForm({ eventType: t })} className="mt-7 inline-flex min-h-11 items-center gap-2 border-t border-primary-foreground/10 pt-5 text-left text-sm font-bold text-gold transition group-hover:border-gold/30">
                  Quero organizar este evento <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
                </button>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ESPAÇO */}
      <section id="espaco" className="section bg-cream-warm">
        <div className="container-x space-y-28">
          <Reveal className="max-w-2xl">
            <p className="eyebrow"><span className="ornament-line" />Conheça nosso espaço</p>
            <h2 className="h2">Cada canto preparado para receber bem.</h2>
          </Reveal>
          {[
            { a: img.espacoDecorado, b: img.mesasConvidados, t: "Salão decorado e mesas para convidados", d: "Um salão amplo e iluminado, com mesas organizadas para que todos aproveitem a festa com conforto." },
            { a: img.brinquedosEspaco, b: img.entradaFachada, t: "Diversão e uma chegada especial", d: "Da fachada à área de brinquedos, o encantamento começa logo na entrada e acompanha a festa inteira." },
          ].map((r, k) => (
            <div key={r.t} className="grid items-center gap-12 lg:grid-cols-12">
              <Reveal className={`grid grid-cols-5 gap-5 lg:col-span-7 ${k % 2 ? "lg:order-2" : ""}`}>
                <SmartImage src={r.a} alt={r.t} className="col-span-3 aspect-[3/4] rounded-[2rem] shadow-elegant" />
                <SmartImage src={r.b} alt={r.t} className="col-span-2 mt-14 aspect-[3/4] rounded-[2rem] border-4 border-card shadow-soft" />
              </Reveal>
              <Reveal className="lg:col-span-5">
                <span className="font-display text-[5.5rem] leading-none text-transparent [-webkit-text-stroke:1.5px_var(--gold)] select-none" aria-hidden="true">0{k + 1}</span>
                <h3 className="mt-3 font-display text-4xl font-semibold leading-tight text-primary">{r.t}</h3>
                <p className="lead">{r.d}</p>
              </Reveal>
            </div>
          ))}
          <div className="text-center"><button onClick={() => openForm({ interest: "Visitar e conhecer o espaço" })} className="btn-primary">Quero conhecer pessoalmente <ArrowRight className="h-4 w-4" /></button></div>
        </div>
      </section>

      {/* GASTRONOMIA */}
      <section className="relative overflow-hidden py-24 md:py-36">
        <div className="container-x grid items-center gap-14 lg:grid-cols-2">
          <Reveal>
            <p className="eyebrow"><span className="ornament-line" />Gastronomia</p>
            <h2 className="h2">Sabores que fazem parte da celebração.</h2>
            <p className="lead">A mesa é um dos grandes encontros da festa. Cuidamos da apresentação do buffet para que cada prato seja um convite à confraternização.</p>
            <p className="lead">Converse com nossa equipe para conhecer as opções disponíveis para o seu evento.</p>
            <button onClick={() => openForm({ interest: "Solicitar um orçamento" })} className="btn-gold mt-9">Solicitar orçamento <ArrowRight className="h-4 w-4" /></button>
          </Reveal>
          <Reveal className="relative">
            <SmartImage src={img.buffetGastronomia} alt="Buffet e apresentação dos alimentos" className="frame-gold aspect-[4/3] rounded-[2.5rem] shadow-elegant" />
            <span className="absolute -bottom-5 -left-5 -z-10 h-40 w-40 rounded-[2rem] bg-gold/25" aria-hidden="true" />
          </Reveal>
        </div>
      </section>

      {/* GALERIA */}
      <section id="galeria" className="section bg-cream-warm">
        <div className="container-x">
          <Reveal className="mb-14 flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
              <p className="eyebrow"><span className="ornament-line" />Galeria</p>
              <h2 className="h2">Momentos no Reino Alegre</h2>
            </div>
            <a href={site.instagram} target="_blank" rel="noopener noreferrer" className="group inline-flex items-center gap-2.5 font-bold text-accent-blue transition hover:text-gold-deep">
              <span className="grid h-11 w-11 place-items-center rounded-full border border-current transition group-hover:shadow-gold"><Instagram className="h-5 w-5" /></span>
              Veja mais no Instagram
            </a>
          </Reveal>
          <div className="grid auto-rows-[230px] grid-cols-2 gap-3.5 md:auto-rows-[270px] md:grid-cols-4 md:gap-5">
            {GALLERY.map((g, i) => (
              <button key={g.src} onClick={() => setZoom(i)} aria-label={`Ampliar: ${g.alt}`} className={`group relative overflow-hidden rounded-[1.4rem] shadow-soft transition-shadow duration-500 hover:shadow-elegant ${g.c ?? ""}`}>
                <SmartImage src={g.src} alt={g.alt} className="h-full w-full transition-transform duration-700 ease-out group-hover:scale-[1.06]" />
                <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-primary/50 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                <span className="pointer-events-none absolute bottom-4 left-4 font-display text-lg italic text-primary-foreground opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100 translate-y-2">{g.alt}</span>
              </button>
            ))}
          </div>
        </div>
      </section>
      {zoom !== null && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-primary/95 p-4 animate-in fade-in" onClick={() => setZoom(null)} role="dialog" aria-modal="true" aria-label="Foto ampliada">
          <button className="absolute right-4 top-4 rounded-full p-3 text-primary-foreground" aria-label="Fechar"><X /></button>
          <div onClick={(e) => e.stopPropagation()} className="w-full max-w-5xl animate-in zoom-in-95">
            <SmartImage key={zoom} src={GALLERY[zoom]!.src} alt={GALLERY[zoom]!.alt} eager className="aspect-[3/2] w-full rounded-2xl" />
            <div className="mt-4 flex items-center justify-between text-primary-foreground">
              <button onClick={() => setZoom((zoom - 1 + GALLERY.length) % GALLERY.length)} className="min-h-11 px-4">← Anterior</button>
              <span className="font-display text-lg italic">{GALLERY[zoom]!.alt}</span>
              <button onClick={() => setZoom((zoom + 1) % GALLERY.length)} className="min-h-11 px-4">Próxima →</button>
            </div>
          </div>
        </div>
      )}

      {/* CTA */}
      <section className="container-x pb-28 pt-4">
        <Reveal className="relative overflow-hidden rounded-[3rem] bg-cta px-6 py-24 text-center text-primary-foreground shadow-elegant md:px-16">
          <span className="pointer-events-none absolute -left-10 top-10 font-display text-[10rem] italic text-gold/10 select-none" aria-hidden="true">✦</span>
          <span className="pointer-events-none absolute -bottom-16 -right-8 font-display text-[12rem] italic text-gold/10 select-none" aria-hidden="true">✦</span>
          <span className="inline-grid h-16 w-16 place-items-center rounded-full border border-gold/50 bg-gold/15"><CalendarHeart className="h-7 w-7 text-gold" /></span>
          <h2 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-semibold leading-tight md:text-6xl">Vamos planejar um dia inesquecível?</h2>
          <p className="mx-auto mt-6 max-w-xl leading-relaxed text-primary-foreground/80">Conte um pouco sobre sua celebração e converse com nossa equipe para conhecer as possibilidades.</p>
          <div className="mt-11 flex flex-col justify-center gap-4 sm:flex-row">
            <button onClick={meeting} className="btn-gold">Agende sua reunião</button>
            <button onClick={() => openForm()} className="btn-ghost">Fale sobre seu evento</button>
          </div>
        </Reveal>
      </section>

      {/* CONTATO */}
      <section id="contato" className="section bg-cream-warm">
        <div className="container-x grid gap-14 lg:grid-cols-2">
          <Reveal>
            <p className="eyebrow"><span className="ornament-line" />Localização e contato</p>
            <h2 className="h2">Venha nos visitar na Maraponga.</h2>
            <div className="mt-10 space-y-4">
              <a href={site.maps} target="_blank" rel="noopener noreferrer" className="contact-card"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gold/15 text-gold-deep"><MapPin /></span><span><b className="block font-display text-xl text-primary">Endereço</b><span className="text-muted-foreground">{site.address}</span></span></a>
              <a href={waLink("Olá! Vim pelo site do Reino Alegre Buffet e gostaria de atendimento.")} target="_blank" rel="noopener noreferrer" className="contact-card"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gold/15 text-gold-deep"><MessageCircle /></span><span><b className="block font-display text-xl text-primary">WhatsApp</b><span className="text-muted-foreground">{site.whatsappDisplay}</span></span></a>
              <a href={site.instagram} target="_blank" rel="noopener noreferrer" className="contact-card"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gold/15 text-gold-deep"><Instagram /></span><span><b className="block font-display text-xl text-primary">Instagram</b><span className="text-muted-foreground">@reinoalegrebuffet</span></span></a>
            </div>
            <div className="mt-9 flex flex-col gap-4 sm:flex-row">
              <a href={site.maps} target="_blank" rel="noopener noreferrer" className="btn-primary"><MapPin className="h-5 w-5" /> Como chegar</a>
              <button onClick={meeting} className="btn-gold">Solicitar reunião</button>
            </div>
          </Reveal>
          <Reveal><SmartImage src={img.entradaFachada} alt="Fachada do Reino Alegre Buffet" className="frame-gold aspect-[4/3] h-full min-h-80 rounded-[2.5rem] shadow-elegant" /></Reveal>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-navy-deep pb-28 pt-20 text-primary-foreground/80 md:pb-12">
        <div className="container-x grid gap-12 md:grid-cols-3">
          <div>
            <p className="font-display text-4xl text-primary-foreground">Reino Alegre</p>
            <p className="mt-1.5 font-display text-xl italic text-gold">{site.slogan}</p>
            <span className="ornament-line mt-6" aria-hidden="true" />
          </div>
          <nav className="grid grid-cols-2 gap-2" aria-label="Rodapé">{NAV.map(([l, id]) => <button key={id} onClick={() => go(id)} className="min-h-10 text-left transition hover:text-gold">{l}</button>)}</nav>
          <div className="space-y-2.5 text-sm">
            <p>{site.address}</p>
            <a href={site.instagram} target="_blank" rel="noopener noreferrer" className="block transition hover:text-gold">Instagram @reinoalegrebuffet</a>
            <a href={`https://wa.me/${site.whatsappNumber}`} target="_blank" rel="noopener noreferrer" className="block transition hover:text-gold">WhatsApp {site.whatsappDisplay}</a>
          </div>
        </div>
        <p className="container-x mt-14 border-t border-primary-foreground/10 pt-7 text-xs">© {new Date().getFullYear()} Reino Alegre Buffet. Todos os direitos reservados.</p>
      </footer>

      <a href={waLink("Olá! Vim pelo site do Reino Alegre Buffet e gostaria de atendimento.")} target="_blank" rel="noopener noreferrer" aria-label="Falar no WhatsApp"
        className="fixed bottom-5 right-5 z-50 grid h-16 w-16 place-items-center rounded-full bg-whatsapp text-primary-foreground shadow-elegant transition hover:scale-110 animate-pulse-wa">
        <MessageCircle className="h-8 w-8" />
      </a>
      <ContactModal open={open} preset={preset} onClose={close} />
    </div>
  );
}
