// Caminhos centralizados das fotografias reais (coloque os arquivos em public/images/).
export const siteImages = {
  heroFesta: "/images/hero-festa.webp",
  heroAmbiente: "/images/hero-ambiente.webp",
  logo: "/images/logo-monograma.png",
  decoracaoPersonalizada: "/images/decoracao-personalizada.webp",
  espacoDecorado: "/images/espaco-decorado.webp",
  mesasConvidados: "/images/mesas-convidados.webp",
  buffetGastronomia: "/images/buffet-gastronomia.webp",
  brinquedosEspaco: "/images/brinquedos-espaco.webp",
  entradaFachada: "/images/entrada-fachada.webp",
  galeriaFesta: "/images/galeria-festa.webp",
  galeriaAniversario: "/images/galeria-aniversario.webp",
  galeriaEspaco: "/images/galeria-espaco.webp",
  galeriaBuffet: "/images/galeria-buffet.webp",
  decoracaoJunina: "/images/decoracao-junina.webp",
  mesaAzul: "/images/mesa-azul.webp",
} as const;

export const site = {
  name: "Reino Alegre Buffet",
  slogan: "Festejar faz bem.",
  address: "Av. Godofredo Maciel, 1181 — Maraponga, Fortaleza/CE",
  instagram: "https://www.instagram.com/reinoalegrebuffet/",
  whatsappDisplay: "+55 85 99622-0363",
  whatsappNumber: "5585996220363",
  maps: "https://www.google.com/maps/search/?api=1&query=" +
    encodeURIComponent("Av. Godofredo Maciel, 1181, Maraponga, Fortaleza, CE"),
};
