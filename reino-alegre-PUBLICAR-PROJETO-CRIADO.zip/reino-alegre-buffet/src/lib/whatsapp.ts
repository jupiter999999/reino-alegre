import { site } from "@/data/siteImages";

export const EVENT_TYPES = ["Festa infantil", "Aniversário adulto", "Confraternização", "Evento corporativo", "Outra celebração"] as const;
export const GUESTS = ["Até 50 pessoas", "De 51 a 100 pessoas", "Mais de 100 pessoas", "Ainda não sei"] as const;
export const INTERESTS = ["Agendar uma reunião", "Solicitar um orçamento", "Visitar e conhecer o espaço", "Tirar dúvidas sobre meu evento"] as const;
export const PERIODS = ["Manhã", "Tarde", "Noite", "A combinar"] as const;

export type FormData = {
  name: string;
  eventType: string;
  eventDate: string; // yyyy-mm-dd
  noDate: boolean;
  guests: string;
  interest: string;
  meetingDate: string;
  meetingPeriod: string;
  details: string;
};

export const fmtDate = (iso: string) => {
  const [y, m, d] = iso.split("-");
  return y && m && d ? `${d}/${m}/${y}` : "";
};

export function buildMessage(f: FormData): string {
  const lines = [
    "🎉 REINO ALEGRE BUFFET — NOVO CONTATO PELO SITE",
    "Olá! Gostaria de conversar sobre meu evento.",
    "",
    `👤 Nome: ${f.name.trim()}`,
    `🎂 Tipo de evento: ${f.eventType}`,
    `📅 Data prevista: ${f.noDate || !f.eventDate ? "A definir" : fmtDate(f.eventDate)}`,
    `👥 Convidados: ${f.guests}`,
    `📋 Meu interesse: ${f.interest}`,
  ];
  if (f.interest === "Agendar uma reunião") {
    const d = f.meetingDate ? fmtDate(f.meetingDate) : "A definir";
    const p = f.meetingPeriod ? (f.meetingPeriod === "A combinar" ? "período a combinar" : `à ${f.meetingPeriod.toLowerCase()}`.replace("à manhã", "pela manhã")) : "";
    lines.push(`🗓️ Preferência para reunião: ${d}${p ? `, ${p}` : ""}`);
  }
  if (f.details.trim()) lines.push(`📝 Detalhes: ${f.details.trim()}`);
  lines.push("", "Gostaria de verificar a disponibilidade e conversar sobre as opções. Obrigado(a)!");
  return lines.join("\n");
}

export const waLink = (text: string) => `https://wa.me/${site.whatsappNumber}?text=${encodeURIComponent(text)}`;
