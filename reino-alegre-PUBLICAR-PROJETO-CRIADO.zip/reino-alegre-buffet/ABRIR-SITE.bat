@echo off
setlocal
cd /d "%~dp0"
title Reino Alegre Buffet - Preview local

echo ====================================================
echo    REINO ALEGRE BUFFET - VISUALIZACAO SEM HOSPEDAR

echo ====================================================
echo.
where node >nul 2>&1
if errorlevel 1 (
    echo [AVISO] Node.js nao foi encontrado neste computador.
    echo Instale o Node.js 22 ou superior pelo site oficial:
    echo https://nodejs.org/
    echo Depois abra este arquivo novamente.
    echo.
    pause
    exit /b 1
)
where npm >nul 2>&1
if errorlevel 1 (
    echo [AVISO] npm nao encontrado. Reinstale Node.js com npm.
    pause
    exit /b 1
)

echo Versao instalada:
node --version
if errorlevel 1 (
    echo [ERRO] Nao foi possivel executar o Node.js.
    pause
    exit /b 1
)

echo.
if not exist "node_modules\vite\bin\vite.js" (
    echo Primeira abertura: instalando dependencias.
    echo Esta etapa precisa de internet e pode levar alguns minutos.
    echo.
    call npm install
    if errorlevel 1 (
        echo.
        echo [ERRO] Falha ao instalar dependencias. Confira sua internet
        echo e a versao do Node.js. Nao foi alterado o codigo do site.
        pause
        exit /b 1
    )
)

echo.
echo Iniciando a visualizacao LOCAL do site...
echo Endereco: http://localhost:5173

echo Nao feche esta janela enquanto estiver vendo o site.
echo Para desligar, pressione CTRL+C nesta janela.
echo.
start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ABRIR-NAVEGADOR.ps1"
call npm run dev -- --host 127.0.0.1 --port 5173 --strictPort
if errorlevel 1 (
    echo.
    echo [ERRO] O servidor nao iniciou. Verifique os erros acima.
    echo Se a porta 5173 estiver ocupada, feche outro site de testes.
    pause
)
endlocal
