@echo off
setlocal
cd /d "%~dp0"
title REINO ALEGRE - Publicar no projeto correto
cls
echo ==========================================================
echo   REINO ALEGRE BUFFET - PUBLICAR NO VERCEL
echo   Projeto criado: reino-alegre-buffet
echo   NAO ALTERA O ESPACO FLOW
echo ==========================================================
echo.
if not exist ".vercel\project.json" (
  echo [ERRO] A vinculacao segura ao projeto nao foi encontrada.
  pause
  exit /b 1
)
findstr /C:"prj_N1LSjmi57UzuuAPg3GYxqHNV3lgo" ".vercel\project.json" >nul
if errorlevel 1 (
  echo [ERRO] Projeto Vercel diferente do Reino Alegre. Operacao cancelada.
  pause
  exit /b 1
)
findstr /C:"team_k8RnKw8JoCXBiIaDYYG4Rqam" ".vercel\project.json" >nul
if errorlevel 1 (
  echo [ERRO] Equipe Vercel incorreta. Operacao cancelada.
  pause
  exit /b 1
)
where node >nul 2>&1
if errorlevel 1 (
  echo [ERRO] Instale Node.js pelo site https://nodejs.org
  pause
  exit /b 1
)
where npx >nul 2>&1
if errorlevel 1 (
  echo [ERRO] Npx nao encontrado. Reinstale Node.js.
  pause
  exit /b 1
)
echo Este projeto ja esta vinculado ao Reino Alegre Buffet.
echo Na primeira vez, abra o link de login da Vercel quando solicitado.
echo NAO sera criado um projeto novo e NAO sera alterado o Flow.
echo.
call npx --yes vercel@latest deploy --prod --yes --scope espacoflow
if errorlevel 1 (
  echo.
  echo [ERRO] Falha no deploy. Envie um print desta tela.
  pause
  exit /b 1
)
echo.
echo [OK] Solicite o endereco acima e confira se esta publicado.
pause
endlocal
