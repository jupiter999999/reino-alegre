$site = 'http://localhost:5173/'
$limite = (Get-Date).AddSeconds(120)
while ((Get-Date) -lt $limite) {
    try {
        $resp = Invoke-WebRequest -Uri $site -TimeoutSec 3 -UseBasicParsing
        if ($resp.StatusCode -ge 200 -and $resp.StatusCode -lt 500) {
            Start-Process $site
            exit 0
        }
    } catch {
        # Aguardando o servidor iniciar.
    }
    Start-Sleep -Seconds 2
}
Write-Output "O servidor demorou a iniciar. Abra manualmente: $site"
